"""
Persona 4 - Página web con Flask.
Muestra en una tabla los datos de alumnos.json.

Por ahora lee/escribe el JSON local (data/alumnos.json).
La Persona 5 solo debe reemplazar las funciones leer_alumnos() y
guardar_alumnos() por las del script de la Persona 3 (boto3 + S3).
"""
import json
import math
import re
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash
import os
import boto3
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = "practica-s3-flask"  # solo para mostrar mensajes flash

ARCHIVO_LOCAL = Path(__file__).parent / "data" / "alumnos.json"
BUCKET = os.getenv("S3_BUCKET_NAME")
ARCHIVO_S3 = os.getenv("S3_OBJECT_KEY")
REGION = os.getenv("AWS_REGION")

s3 = boto3.client("s3", region_name=REGION)

# ---------- Reglas de validación ----------
LETRAS = "A-Za-zÁÉÍÓÚÜÑáéíóúüñ"
NOMBRE_RE = re.compile(rf"^[{LETRAS}][{LETRAS} .'-]{{1,59}}$")      # solo letras y espacios
CARRERA_RE = re.compile(rf"^[{LETRAS}][{LETRAS} .'-]{{1,59}}$")     # solo letras y espacios
MATRICULA_RE = re.compile(r"^[A-Za-z0-9]{3,15}$")                   # letras y números, sin signos
GRUPO_RE = re.compile(r"^[A-Za-z0-9-]{1,10}$")                      # ej. ISC-5A


def validar_alumno(form, existentes):
    """Devuelve (alumno, errores). Si hay errores, alumno es None."""
    matricula = form.get("matricula", "").strip()
    nombre = " ".join(form.get("nombre", "").split())
    carrera = " ".join(form.get("carrera", "").split())
    grupo = form.get("grupo", "").strip()
    errores = []

    if not MATRICULA_RE.match(matricula):
        errores.append("La matrícula debe tener de 3 a 15 letras o números, sin signos ni espacios (no se permiten negativos).")
    elif any(a["matricula"].lower() == matricula.lower() for a in existentes):
        errores.append(f"La matrícula {matricula} ya existe.")

    if not NOMBRE_RE.match(nombre):
        errores.append("El nombre solo puede llevar letras y espacios (no números).")

    if not CARRERA_RE.match(carrera):
        errores.append("La carrera solo puede llevar letras y espacios.")

    if not GRUPO_RE.match(grupo):
        errores.append("El grupo solo puede llevar letras, números y guion (máx. 10 caracteres).")

    try:
        promedio = float(form.get("promedio", ""))
        if not math.isfinite(promedio) or not 0 <= promedio <= 10:
            errores.append("El promedio debe estar entre 0 y 10.")
    except ValueError:
        promedio = None
        errores.append("El promedio debe ser un número.")

    if errores:
        return None, errores
    return {"matricula": matricula, "nombre": nombre, "carrera": carrera,
            "grupo": grupo, "promedio": round(promedio, 1)}, []


# ---------- Capa de datos conectada con Amazon S3 ----------

def leer_alumnos():
    """Lee los alumnos desde Amazon S3."""
    respuesta = s3.get_object(
        Bucket=BUCKET,
        Key=ARCHIVO_S3
    )

    contenido = respuesta["Body"].read().decode("utf-8")
    return json.loads(contenido)


def guardar_alumnos(alumnos):
    """Guarda los alumnos en Amazon S3."""
    contenido = json.dumps(
        alumnos,
        ensure_ascii=False,
        indent=2
    )

    s3.put_object(
        Bucket=BUCKET,
        Key=ARCHIVO_S3,
        Body=contenido.encode("utf-8"),
        ContentType="application/json"
    )


# ---------- Rutas ----------
@app.route("/")
def index():
    try:
        alumnos = leer_alumnos()
        error = None
    except FileNotFoundError:
        alumnos, error = [], "No se encontró el archivo alumnos.json."
    except Exception as e:  # permisos, JSON inválido, etc.
        alumnos, error = [], f"No se pudieron leer los datos: {e}"

    promedio = round(sum(a["promedio"] for a in alumnos) / len(alumnos), 2) if alumnos else 0
    return render_template("index.html", alumnos=alumnos, error=error, promedio=promedio)


@app.route("/agregar", methods=["POST"])
def agregar():
    try:
        alumnos = leer_alumnos()
        nuevo, errores = validar_alumno(request.form, alumnos)
        if errores:
            for e in errores:
                flash(e, "error")
        else:
            alumnos.append(nuevo)
            guardar_alumnos(alumnos)
            flash("Alumno guardado.", "ok")
    except Exception as e:
        flash(f"No se pudo guardar: {e}", "error")
    return redirect(url_for("index"))


@app.route("/api/alumnos")
def api_alumnos():
    """Muestra el JSON crudo (útil para la demostración)."""
    return app.response_class(
        json.dumps(leer_alumnos(), ensure_ascii=False, indent=2),
        mimetype="application/json",
    )


if __name__ == "__main__":
    app.run(debug=True)
