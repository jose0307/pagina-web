// Buscador en vivo: filtra las filas de la tabla mientras escribes.
const buscador = document.getElementById("buscador");
const filas = document.querySelectorAll("#tabla-alumnos tbody tr[data-fila]");
const contador = document.getElementById("contador");

if (buscador) {
  buscador.addEventListener("input", () => {
    const texto = buscador.value.trim().toLowerCase();
    let visibles = 0;
    filas.forEach((fila) => {
      const coincide = fila.textContent.toLowerCase().includes(texto);
      fila.style.display = coincide ? "" : "none";
      if (coincide) visibles++;
    });
    contador.textContent = texto ? `${visibles} resultado(s)` : "";
  });
}
